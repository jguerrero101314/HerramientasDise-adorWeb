Current Font Awesome Version
Included in Metro Notification v7



http://fortawesome.github.io/Font-Awesome/icons/



For MAC users 
Font Awesome Icons.webloc

Is a shortcut.


